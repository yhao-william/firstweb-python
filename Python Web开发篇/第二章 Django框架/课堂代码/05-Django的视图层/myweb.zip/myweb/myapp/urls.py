from django.urls import path
from . import views
from myapp.views import MyView

urlpatterns = [
    path('', views.index, name="index"), #首页
    
    path('resp01', views.resp01, name="resp01"), #一个简单的视图
    path('resp02', views.resp02, name="resp02"), #返回一个错误
    path('resp03', views.resp03, name="resp03"), #重定向
    path('resp04', MyView.as_view(), name="resp04"), #基本类的视图
    path('resp05', views.resp05, name="resp05"), #响应json数据
    path('resp06', views.resp06, name="resp06"), #Cookie的使用
    path('resp07', views.resp07, name="resp07"), #测试request请求对象
    path('resp08', views.verifycode, name="resp08"), #验证码的输出

]