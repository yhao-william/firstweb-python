from django.shortcuts import render
from django.http import HttpResponse,Http404
from django.urls import reverse
from django.shortcuts import redirect
# Create your views here.
def index(request):
    print(reverse("add")) #reverse通过路由名称反向生成url请求地址
    print(reverse("index"))
    print(reverse("find3",args=(100,'lisi')))
    #return redirect(reverse("find3",args=(100,'lisi'))) #执行浏览器重定向
    return HttpResponse("Hello World!")

def add(request):
    return HttpResponse("add....")

#def find(request,sid):
#    return HttpResponse("find.....%d"%(sid))

def find(request,sid=0,name=""):
    return HttpResponse("find2.....%d:%s"%(sid,name))

def update(request):
    #return HttpResponse("update....")
    raise Http404('修改页面不存在！')

def fun(request,mm,yy):
    return HttpResponse("参数信息：%s年%s月"%(yy,mm))
